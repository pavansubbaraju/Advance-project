package myService;
/*
 * 鑷畾涔変竴涓紓甯哥被
 * 鍙槸缁欏嚭鐖剁被涓殑鏋勯�鍣ㄥ嵆鍙紝鏂逛究鐢ㄦ潵鍒涘缓瀵硅薄
 */
public class UserException extends Exception{

	public UserException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public UserException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public UserException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	

}
